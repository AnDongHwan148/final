package com.kh.sm.common;

import java.util.UUID;

public class CommonUtils {
	
	
	public static String getRandomString() {
		
		
		//32비트의 랜덤한 문자열을 생성해준다.
		return UUID.randomUUID().toString().replace("-", "");
	}
	
	
	

}
